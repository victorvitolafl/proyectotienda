<?php
$id = $_POST['id'];
$nuevoprecio = $_POST['nuevoprecio'];

include('conexion.php');


$query = "UPDATE producto SET precio = '$nuevoprecio' WHERE id = $id";
$respuesta = $con->query($query);
if ($respuesta) {
    echo '<script language="javascript">alert("Se ha actualizado el precio.");window.location.href="formprecioproducto.html"</script>';
} else {
    echo '<script language="javascript">alert("No se ha podido actualizar el precio.");window.location.href="formprecioproducto.html"</script>';
}


$con->close()
    ?>