<?php

$total = $_POST['total'];
$estado = $_POST['estado'];
$idcliente = $_POST['idcliente'];


include('conexion.php');


$query = "INSERT INTO creditos (total, estado, idcliente) VALUES ('$total', '$estado', '$idcliente')";
$respuesta = $con->query($query);

echo '<script language="javascript">alert("credito agregado con éxito.");window.location.href="formulariocredito.php"</script>';



$con->close()
    ?>