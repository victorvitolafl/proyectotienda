<?php
$id = $_POST['id'];
$nuevocorreo = $_POST['nuevocorreo'];

include('conexion.php');


$query = "UPDATE proveedor SET correo = '$nuevocorreo' WHERE id = $id";
$respuesta = $con->query($query);
if ($respuesta) {
    echo '<script language="javascript">alert("Se ha actualizado el correo.");window.location.href="formcorreoproveedor.php"</script>';
} else {
    echo '<script language="javascript">alert("No se ha podido actualizar el correo.");window.location.href="formcorreoproveedor.php"</script>';
}


$con->close()
    ?>