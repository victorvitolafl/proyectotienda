<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Eliminar</title>
</head>

<body>
    <header>
        <nav class="navbar" style="background-color: #C82333">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand text-light" style="margin-left: 10px;" href="index.html">SISTEMA TIENDA</a>
                </div>
                <ul class="nav justify-content-end">
                    <li class="nav-item">
                        <a class="nav-link active text-light" href="index.html">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menuinsertar.html">Insertar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menumostrar.html">Mostrar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menuactualizar.html">Actualizar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menuborrar.html">Borrar</a>

                </ul>
            </div>
        </nav>
    </header>



    <form action="borrarcliente.php" method="post" style="margin-left: 50px;">
        <hr>
        <h1 style="margin-top: 10px;">Cliente </h1>
        <div class="form-group row">
            <label for="id" class="col-2 col-form-label">ID cliente</label>
            <div class="col-4">
                <input id="id" name="id" type="number" class="form-control" required="required">
            </div>
        </div>
        <hr>
        <div class="form-group row">
            <div class="offset-2 col-4">
                <button name="submit" type="submit" class="btn bg-danger">Eliminar</button>
            </div>
        </div>
    </form>

</body>

</html>