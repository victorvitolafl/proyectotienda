<?php
$id = $_POST['id'];

include('conexion.php');

$query = "DELETE FROM cliente WHERE id = $id;";
$respuesta = $con->query($query);
if ($respuesta) {
    echo '<script language="javascript">alert("Se ha eliminado el cliente.");window.location.href="formborrarcliente.php"</script>';
} else {
    echo '<script language="javascript">alert("No se ha podido eliminar el cliente.");window.location.href="formborrarcliente.php"</script>';
}

$con->close()
    ?>