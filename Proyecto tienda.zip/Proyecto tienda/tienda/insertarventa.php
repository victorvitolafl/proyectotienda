<?php
$total = $_POST['total'];

include('conexion.php');

$sql = "INSERT INTO ventas (total) 
values('$total')";
$rsf = mysqli_query($con, $sql);

echo '<script language="javascript">alert("Venta registrada con éxito.");window.location.href="formularioventa.html"</script>';

$con->close()
    ?>