<?php
$id = $_POST['id'];


include('conexion.php');


$query = "DELETE FROM producto WHERE id = $id";
$respuesta = $con->query($query);
if ($respuesta) {
    echo '<script language="javascript">alert("Se ha eliminado el cliente.");window.location.href="formborrarproducto.php"</script>';
} else {
    echo '<script language="javascript">alert("No se ha podido eliminar el cliente.");window.location.href="formborrarproducto.php"</script>';
}


$con->close()
    ?>