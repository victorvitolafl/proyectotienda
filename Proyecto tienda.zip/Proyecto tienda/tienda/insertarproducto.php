<?php
$id = $_POST['id'];
$descripcion = $_POST['descripcion'];
$precio = $_POST['precio'];
$categoria = $_POST['categoria'];

include('conexion.php');

$sqlvalidar = "SELECT * FROM producto WHERE id = '$id';";
$existe = $con->query($sqlvalidar);
$cant = $existe->num_rows;

if ($cant == 0) {
    $query = "INSERT INTO producto(id, descripcion, precio, categoria) VALUES ('$id','$descripcion','$precio','$categoria')";
    $respuesta = $con->query($query);
    if ($respuesta) {
        echo '<script language="javascript">alert("Producto agregado con éxito.");window.location.href="formularioproducto.html"</script>';
    } else
        echo "Error insertando el registro";
} else {
    echo '<script language="javascript">alert("Ya existe un producto con esta id.");window.location.href="formularioproducto.html"</script>';

}

$con->close()
    ?>