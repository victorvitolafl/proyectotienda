<?php
$id = $_POST['id'];
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$ciudad = $_POST['ciudad'];
$telefono = $_POST['telefono'];

include('conexion.php');

$sqlvalidar = "SELECT * FROM proveedor WHERE id = '$id';";
$existe = $con->query($sqlvalidar);
$cant = $existe->num_rows;

if ($cant == 0) {
    $query = "INSERT INTO proveedor(id, nombre, correo, ciudad, telefono) VALUES ('$id','$nombre','$correo','$ciudad','$telefono')";
    $respuesta = $con->query($query);
    if ($respuesta) {
        echo '<script language="javascript">alert("Proveedor agregado con éxito.");window.location.href="formularioproveedor.html"</script>';
    } else
        echo "Error insertando el registro";
} else {
    echo '<script language="javascript">alert("Ya existe un proveedor con esta id.");window.location.href="formularioproveedor.html"</script>';

}

$con->close()
    ?>