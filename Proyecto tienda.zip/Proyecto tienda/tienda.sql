-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-12-2022 a las 03:37:02
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `actualizar_direccion_emple` (IN `_id` INT, IN `_direc` VARCHAR(20))   BEGIN 
  UPDATE empleados 
  SET direccion = _direc
  WHERE id = _id;
  END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `eliminar_empleado` (IN `_id` INT)   BEGIN
  DELETE FROM empleados WHERE id = _id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `mostrar_clientes` ()   BEGIN
  SELECT * FROM cliente;
  END$$

--
-- Funciones
--
CREATE DEFINER=`root`@`localhost` FUNCTION `mostrar` (`cat` VARCHAR(20)) RETURNS INT(20)  BEGIN
DECLARE numero int;
SELECT COUNT(*) INTO numero FROM producto WHERE categoria = cat;
RETURN numero;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `mostrar_productos` (`producto` VARCHAR(20)) RETURNS INT(20)  BEGIN
DECLARE numero int;
SELECT COUNT(*) INTO numero FROM producto;
RETURN numero;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `edad` int(11) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `telefono` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Disparadores `cliente`
--
DELIMITER $$
CREATE TRIGGER `copia_cliente` AFTER INSERT ON `cliente` FOR EACH ROW BEGIN
INSERT INTO espejo_cliente (id, nombre, edad, direccion, telefono) VALUES (NEW.id, NEW.nombre, NEW.edad, NEW.direccion, NEW.telefono);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `creditos`
--

CREATE TABLE `creditos` (
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total` float NOT NULL,
  `estado` varchar(250) NOT NULL,
  `idcliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Disparadores `creditos`
--
DELIMITER $$
CREATE TRIGGER `copia_credito` AFTER INSERT ON `creditos` FOR EACH ROW BEGIN
INSERT INTO espejo_credito(fecha, total, estado, idcliente) VALUES (NEW.fecha, NEW.total, NEW.estado, NEW.idcliente);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `id` int(11) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `sexo` varchar(250) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `edad` int(11) NOT NULL,
  `correo` varchar(250) NOT NULL,
  `sueldo` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Disparadores `empleados`
--
DELIMITER $$
CREATE TRIGGER `copia_empleados` AFTER INSERT ON `empleados` FOR EACH ROW BEGIN
INSERT INTO espejo_empleados(id, nombre, sexo, direccion, telefono, edad, correo, sueldo) VALUES(NEW.id, NEW.nombre, NEW.sexo, NEW.direccion, NEW.telefono, NEW.edad, NEW.correo, NEW.sueldo);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `espejo_cliente`
--

CREATE TABLE `espejo_cliente` (
  `id` int(11) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `edad` int(11) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `telefono` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `espejo_credito`
--

CREATE TABLE `espejo_credito` (
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total` float NOT NULL,
  `estado` varchar(250) NOT NULL,
  `idcliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `espejo_empleados`
--

CREATE TABLE `espejo_empleados` (
  `id` int(11) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `sexo` varchar(250) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `edad` int(11) NOT NULL,
  `correo` varchar(250) NOT NULL,
  `sueldo` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `espejo_factura`
--

CREATE TABLE `espejo_factura` (
  `codigo` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total` float NOT NULL,
  `idcliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `espejo_producto`
--

CREATE TABLE `espejo_producto` (
  `id` int(11) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `precio` float NOT NULL,
  `categoria` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `espejo_proveedor`
--

CREATE TABLE `espejo_proveedor` (
  `id` int(11) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `correo` varchar(250) NOT NULL,
  `ciudad` varchar(250) NOT NULL,
  `telefono` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `espejo_ventas`
--

CREATE TABLE `espejo_ventas` (
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `codigo` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total` float NOT NULL,
  `idcliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id` int(11) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `precio` float NOT NULL,
  `categoria` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Disparadores `producto`
--
DELIMITER $$
CREATE TRIGGER `copia_producto` AFTER INSERT ON `producto` FOR EACH ROW BEGIN
INSERT INTO espejo_producto(id, descripcion, precio, categoria) VALUES(NEW.id, NEW.descripcion, NEW.precio, NEW.categoria);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `id` int(11) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `correo` varchar(250) NOT NULL,
  `ciudad` varchar(250) NOT NULL,
  `telefono` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Disparadores `proveedor`
--
DELIMITER $$
CREATE TRIGGER `copia_proveedor` AFTER INSERT ON `proveedor` FOR EACH ROW BEGIN
INSERT INTO espejo_proveedor(id,nombre,correo,ciudad,telefono) VALUES(NEW.id,NEW.nombre,NEW.correo,NEW.ciudad,NEW.telefono);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Disparadores `ventas`
--
DELIMITER $$
CREATE TRIGGER `copia_ventas` AFTER INSERT ON `ventas` FOR EACH ROW BEGIN
INSERT INTO espejo_ventas(fecha, total) VALUES(NEW.fecha,NEW.total);
END
$$
DELIMITER ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `creditos`
--
ALTER TABLE `creditos`
  ADD PRIMARY KEY (`fecha`),
  ADD KEY `idcliente` (`idcliente`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`codigo`),
  ADD KEY `idcliente` (`idcliente`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`id`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `creditos`
--
ALTER TABLE `creditos`
  ADD CONSTRAINT `creditos_ibfk_1` FOREIGN KEY (`idcliente`) REFERENCES `cliente` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`idcliente`) REFERENCES `cliente` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
