<?php
$id = $_POST['id'];
$nuevotelefono = $_POST['nuevotelefono'];

include('conexion.php');


$query = "UPDATE cliente SET telefono = '$nuevotelefono' WHERE id = $id";
$respuesta = $con->query($query);
if ($respuesta) {
    echo '<script language="javascript">alert("Se ha actualizado el telefono.");window.location.href="formtelefonocliente.html"</script>';
} else {
    echo '<script language="javascript">alert("No se ha podido actualizar el teléfono.");window.location.href="formtelefonocliente.html"</script>';
}


$con->close()
    ?>