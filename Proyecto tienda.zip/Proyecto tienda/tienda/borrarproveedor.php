<?php
$id = $_POST['id'];

include('conexion.php');

$query = "DELETE FROM proveedor WHERE id = $id;";
$respuesta = $con->query($query);
if ($respuesta) {
    echo '<script language="javascript">alert("Se ha eliminado el proveedor.");window.location.href="formborrarproveedor.php"</script>';
} else {
    echo '<script language="javascript">alert("No se ha podido eliminar el proveedor.");window.location.href="formborrarproveedor.php"</script>';
}

$con->close()
    ?>