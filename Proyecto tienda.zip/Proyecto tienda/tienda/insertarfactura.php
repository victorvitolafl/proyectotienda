<?php
$codigo = $_POST['codigo'];
$total = $_POST['total'];
$idcliente = $_POST['idcliente'];


include('conexion.php');

$sqlvalidar = "SELECT * FROM factura WHERE codigo = '$codigo';";
$existe = $con->query($sqlvalidar);
$cant = $existe->num_rows;

if ($cant == 0) {
    $query = "INSERT INTO factura(codigo, total, idcliente) VALUES ('$codigo','$total','$idcliente')";
    $respuesta = $con->query($query);
    if ($respuesta) {
        echo '<script language="javascript">alert("Factura agregada con éxito.");window.location.href="formulariofactura.php"</script>';

    } else {
        echo '<script language="javascript">alert("Ya existe una Factura con esta codigo.");window.location.href="formulariofactura.php"</script>';
    }
}

$con->close()
    ?>