<!DOCTYPE html>

<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Facturas</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="">
</head>

<body>

    <header>
        <nav class="navbar navbar-default bg-primary ">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand text-light" style="margin-left: 10px;" href="index.html">SISTEMA TIENDA</a>
                </div>
                <ul class="nav justify-content-end">
                    <li class="nav-item">
                        <a class="nav-link active text-light" href="index.html">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menuinsertar.html">Insertar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menumostrar.html">Mostrar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menuactualizar.html">Actualizar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menuborrar.html">Borrar</a>

                </ul>
            </div>
        </nav>
    </header>

    <table class="table container mt-4">
        <thead class="table-dark">
            <th>C&oacute;digo</th>
            <th>Fecha</th>
            <th>Total</th>
            <th>ID Cliente</th>
        </thead>

        <?php

        include('conexion.php');
        $sql = "SELECT * FROM factura";
        $resultado = $con->query($sql);

        while ($muestra = mysqli_fetch_array($resultado)) {
        ?>

        <tbody>
            <td>
                <?php echo $muestra['codigo'] ?>
            </td>
            <td>
                <?php echo $muestra['fecha'] ?>
            </td>
            <td>
                <?php echo $muestra['total'] ?>
            </td>
            <td>
                <?php echo $muestra['idcliente'] ?>
            </td>
        </tbody>


        <?php
        }
        ?>

    </table>


</body>

</html>