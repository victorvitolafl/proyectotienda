<?php
$id = $_POST['id'];
$nombre = $_POST['nombre'];
$edad = $_POST['edad'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];

include('conexion.php');

$sqlvalidar = "SELECT * FROM cliente WHERE id = '$id';";
$existe = $con->query($sqlvalidar);
$cant = $existe->num_rows;

if ($cant == 0) {
    $query = "INSERT INTO cliente (id, nombre, edad, direccion, telefono) VALUES ('$id','$nombre','$edad','$direccion','$telefono')";
    $respuesta = $con->query($query);
    if ($respuesta) {
        echo '<script language="javascript">alert("Cliente agregado con éxito.");window.location.href="formulariocliente.php"</script>';
    } else {
        echo '<script language="javascript">alert("Ya existe un cliente con esta id.");window.location.href="formulariocliente.php"</script>';
    }
}

$con->close()
    ?>