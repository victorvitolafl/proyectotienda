<?php
$id = $_POST['id'];
$nombre = $_POST['nombre'];
$sexo = $_POST['sexo'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];
$edad = $_POST['edad'];
$correo = $_POST['correo'];
$sueldo = $_POST['sueldo'];

include('conexion.php');

$sqlvalidar = "SELECT * FROM empleados WHERE id = '$id';";
$existe = $con->query($sqlvalidar);
$cant = $existe->num_rows;

if ($cant == 0) {
    $query = "INSERT INTO empleados(id, nombre, sexo, direccion, telefono, edad, correo, sueldo) VALUES ('$id','$nombre','$sexo','$direccion','$telefono', '$edad', '$correo', '$sueldo')";
    $respuesta = $con->query($query);
    if ($respuesta) {
        echo '<script language="javascript">alert("Empleado agregado con éxito.");window.location.href="formularioempleados.html"</script>';
    } else
        echo "Error insertando el registro";
} else {
    echo '<script language="javascript">alert("Ya existe un Empleado con esta id.");window.location.href="formularioempleados.html"</script>';

}

$con->close()
    ?>