<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Insertar cliente</title>
</head>

<body>
    <header>
        <nav class="navbar" style="background-color: #6C757D;">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand text-light" style="margin-left: 10px;" href="index.html">SISTEMA TIENDA</a>
                </div>
                <ul class="nav justify-content-end">
                    <li class="nav-item">
                        <a class="nav-link active text-light" href="index.html">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menuinsertar.html">Insertar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menumostrar.html">Mostrar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menuactualizar.html">Actualizar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="menuborrar.html">Borrar</a>

                </ul>
            </div>
        </nav>
    </header>



    <form action="insertarcliente.php" method="post" style="margin-left: 50px;">
        <hr>
        <h1 style="margin-top: 10px;">Cliente </h1>
        <div class="form-group row" style="margin-top: 50px;">
            <label for="id" class="col-2 col-form-label">Id Cliente</label>
            <div class="col-4">
                <input id="id" name="id" type="text" class="form-control" required="required">
            </div>
        </div>
        <div class="form-group row">
            <label for="nombre" class="col-2 col-form-label">Nombre</label>
            <div class="col-4">
                <input id="nombre" name="nombre" type="text" class="form-control" required="required">
            </div>
        </div>
        <div class="form-group row">
            <label for="edad" class="col-2 col-form-label">Edad</label>
            <div class="col-4">
                <input id="edad" name="edad" type="number" class="form-control" required="required">
            </div>
        </div>
        <div class="form-group row">
            <label for="direccion" class="col-2 col-form-label">Direcci&oacute;n</label>
            <div class="col-4">
                <input id="direccion" name="direccion" type="text" class="form-control" required="required">
            </div>
        </div>
        <div class="form-group row">
            <label for="telefono" class="col-2 col-form-label">Tel&eacute;fono</label>
            <div class="col-4">
                <input id="telefono" name="telefono" type="tel" class="form-control" required="required">
            </div>
        </div>
        <hr>
        <div class="form-group row">
            <div class="offset-2 col-4">
                <button name="submit" type="submit" class="btn bg-success">Guardar</button>
            </div>
        </div>
    </form>

</body>

</html>