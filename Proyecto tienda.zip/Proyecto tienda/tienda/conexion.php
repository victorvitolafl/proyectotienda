<?php
$host = "localhost";
$db = "tienda";
$user = "root";
$pas = "";

$con = new mysqli($host, $user, $pas, $db);

    ?>