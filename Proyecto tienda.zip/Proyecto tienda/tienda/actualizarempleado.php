<?php
$id = $_POST['id'];
$nuevadireccion = $_POST['nuevadireccion'];

include('conexion.php');


$query = "UPDATE empleados SET direccion = '$nuevadireccion' WHERE id = $id";
$respuesta = $con->query($query);
if ($respuesta) {
    echo '<script language="javascript">alert("Se ha actualizado la dirección.");window.location.href="formdireccionempleado.php"</script>';
} else {
    echo '<script language="javascript">alert("No se ha podido actualizar la dirección.");window.location.href="formdireccionempleado.php"</script>';
}


$con->close()
    ?>